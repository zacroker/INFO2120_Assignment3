﻿TRUNCATE Booking;
TRUNCATE Journey;
TRUNCATE Vehicle;